package com.jp.hr.services;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jp.hr.entities.Complaint;
import com.jp.hr.exceptions.HrException;
import com.jp.hr.interfaces.ICustomerDAO;

/*
 * One layer refers to another layer through interface only.
 * Implementation if business rules should be done here in absence of Business Layer.
 * This layer will also ensure only custom exceptions to come out.
 * 
 * Features:
 * 		* Only one gateway with preserving privacy of all inner classes.
 * 		* One point for implementing security, transaction management, Caching.
 * 		* Multiple interfaces per client to give restricted view of all services.
 * 		* Facade pattern. (GoF pattern)(One point to connect to multiple services)
 * 		* DAO is a JEE pattern.
 * 		* Implemented singleton by creating single object of outermost class.
 * 		* Delegates and controls Cross Cutting Concerns.
 */
@Service("service")
public class CustomerServiceImpl implements ICustomerService {
	
	private ICustomerDAO daoCmp;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public CustomerServiceImpl() {
	
	}
	
	//Resolving Dependency.
	@Autowired
	// Injection By Name
	public CustomerServiceImpl(@Qualifier("daods") ICustomerDAO daoCmp) throws HrException {
		this.daoCmp = daoCmp;
	}


	@Override
	public Complaint getComplaintDetails(int cmpId) throws HrException {
		// TODO Auto-generated method stub
		return daoCmp.getComplaintDetails(cmpId);
	}

	@Override
	@Transactional
	public boolean insertNewRecord(Complaint cmp) throws HrException {
		System.out.println(cmp);
		System.out.println("bfr insert in impl");
		entityManager.persist(cmp);
		System.out.println("afetr insert in impl");
		return true;
	}


}
