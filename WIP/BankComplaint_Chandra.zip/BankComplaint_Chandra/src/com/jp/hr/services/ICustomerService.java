package com.jp.hr.services;


import com.jp.hr.entities.Complaint;
import com.jp.hr.exceptions.HrException;

public interface ICustomerService {
	
	public Complaint getComplaintDetails(int cmpId) throws HrException;
	public boolean insertNewRecord(Complaint cmp) throws HrException;

}
