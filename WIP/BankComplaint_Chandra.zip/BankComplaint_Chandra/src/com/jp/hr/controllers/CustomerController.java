package com.jp.hr.controllers;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jp.hr.daos.CustomerDAOImpl;
import com.jp.hr.entities.Complaint;


import com.jp.hr.exceptions.HrException;
import com.jp.hr.services.ICustomerService;



// to run the page go to following url : http://localhost:8080/Spring110_MVCBasics/homePage.do

/*
 * @Controller: A kind of @Component to declare SpringMVC Controllers.
 * @RequestMapping: To map a controlling method to the URL.
 * @RequestParam: To take a single QueryString or FormData field Value. 
 * 
 * Multi-action Controllers
 */


@Controller
public class CustomerController {
	@Autowired
	@Qualifier("service")
	private ICustomerService cmpService;
	
	

	//@Autowired
	private Validator validator;
	
	@InitBinder
	private void validateBinder(){
		ValidatorFactory validationFactory = Validation.buildDefaultValidatorFactory();
		validator = validationFactory.getValidator();
	}
	
/*	@RequestMapping("ComplaintRequestForm.hr")
	public String getHomePage(){
		System.out.println("In Complaint Request Form()");
		return "ComplaintRequestForm";
	}*/
	


	@RequestMapping("ComplaintStatus.hr")
	public ModelAndView getComplaintDetails(HttpServletRequest request, @RequestParam("complaintid") int complaintid) {
//		String strEmpId = request.getParameter("id");
//		int empId = Integer.parseInt(strEmpId);
		
		ModelAndView mAndV = new ModelAndView();
		try {
			System.out.println(complaintid);
			Complaint cmp = cmpService.getComplaintDetails(complaintid);
			mAndV.addObject("cmpDetails", cmp);
			System.out.println(cmp);
			mAndV.setViewName("ComplaintStatus");
			
		} catch (HrException e) {
			e.printStackTrace();
		}
		return mAndV;
	}
	

	@RequestMapping("ComplaintStatusForm.hr")
	public String getComplaintStatusForm(Model model) {
		// Define Command Object
		Complaint cmp = new Complaint();
		model.addAttribute("command", cmp);
		
		return "ComplaintStatus";
	}
	
	@RequestMapping("ComplaintRequestForm.hr")
	public String getRegistrationForm(Model model) {
		// Define Command Object
		Complaint cmp = new Complaint();
		model.addAttribute("command", cmp);
		
		return "ComplaintRequestForm";
	}
	
	@RequestMapping("SaveSuccess.hr")
	public String getSuccessPage(Model model) {
		// Define Command Object
		Complaint cmp = new Complaint();
		model.addAttribute("command", cmp);
		
		return "SaveSuccess";
	}
	
	@RequestMapping("submitRegistrationData.hr")
	public String submitRegistrationForm(@ModelAttribute("command") Complaint cmp, BindingResult result, Model model) {
		// Define Command Object
		System.out.println(cmp);
		
	/*	Set<ConstraintViolation<Complaint>> violations = validator.validate(cmp);
    	
    	for (ConstraintViolation<Complaint> violation : violations)
        {
            String propertyPath = violation.getPropertyPath().toString();
            String message = violation.getMessage();
            // Add JSR-303 errors to BindingResult. This allows Spring to display them in view via a FieldError
            FieldError error = new FieldError("command",propertyPath,
                    "Invalid "+ propertyPath + "(" + message + ")");
            result.addError(error);
        }*/
    
    /*	if (result.hasErrors()) {
    		model.addAttribute("msg", "Errors in Entry.");
            return "ComplaintRequestForm";
        } else {*/
        	try {
        		System.out.println("before insert");
    			cmpService.insertNewRecord(cmp);
    			return "SaveSuccess";
    		} catch (HrException e) {
    			model.addAttribute("msg", "Insert Failed!!!" + e.getMessage());
    			return "ComplaintRequestForm";
    		}
        }
		
		
		
/*	}*/
}
