package com.jp.hr.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.stereotype.Repository;


import com.jp.hr.entities.Complaint;
import com.jp.hr.exceptions.HrException;
import com.jp.hr.interfaces.ICustomerDAO;


@Repository("daods")
public class CustomerDAOImpl implements ICustomerDAO {
	
	@PersistenceContext
	private EntityManager entityManager;


@Override
	public Complaint getComplaintDetails(int complaintid) throws HrException {
		Complaint cmp = entityManager.find(Complaint.class,complaintid);
		return cmp;
	}


@Override
public boolean insertNewRecord(Complaint cmp) throws HrException {
	entityManager.persist(cmp);
	return true;
}



}
