package com.jp.hr.entities;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="CMPRec")
@Table(name="complaint")
public class Complaint implements Serializable{

	private int complaintid;
	private int accountid;
	private String branchcode;
	private String emailid;
	private String category;
	private String description;
	private String priority;
	private String status;
	
	@Id
	@SequenceGenerator(name="Comp_Seq",sequenceName="hibernate_sequence",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="Comp_Seq")
	@Column(name="complaintid")
	public int getComplaintid() {
		return complaintid;
	}
	public void setComplaintid(int complaintid) {
		this.complaintid = complaintid;
	}
	@Column(name="accountid")
	public int getAccountid() {
		return accountid;
	}
	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}
	@Column(name="branchcode")
	public String getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}
	@Column(name="emailid")
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	@Column(name="category")
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Column(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Column(name="priority")
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	@Column(name="status")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
	@Override
	public String toString() {
		return "Complaint [complaintid=" + complaintid + ", accountid=" + accountid + ", branchcode=" + branchcode
				+ ", emailid=" + emailid + ", description=" + description + ", priority=" + priority + ", status="
				+ status + "]";
	}
	
	
}
