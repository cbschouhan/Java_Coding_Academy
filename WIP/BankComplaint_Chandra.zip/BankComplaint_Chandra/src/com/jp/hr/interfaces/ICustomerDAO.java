package com.jp.hr.interfaces;


import com.jp.hr.entities.Complaint;

import com.jp.hr.exceptions.HrException;

public interface ICustomerDAO {

	public Complaint getComplaintDetails(int cmpId) throws HrException;
	public boolean insertNewRecord(Complaint cmp) throws HrException;

}
